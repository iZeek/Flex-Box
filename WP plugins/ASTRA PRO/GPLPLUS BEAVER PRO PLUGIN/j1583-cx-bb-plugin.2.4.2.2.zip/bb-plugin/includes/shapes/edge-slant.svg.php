<polygon class="fl-shape" points="0,34 422,0 0,0"></polygon>
