<?php

// Defines
define( 'FL_BUILDER_SEO_PLUGINS_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-seo-plugins/' );
define( 'FL_BUILDER_SEO_PLUGINS_URL', FL_BUILDER_URL . 'extensions/fl-builder-seo-plugins/' );

// Classes
require_once FL_BUILDER_SEO_PLUGINS_DIR . 'classes/class-fl-builder-seo-plugins.php';
